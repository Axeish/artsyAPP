A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/raXPYm.

 Design by Aykut Yılmaz: http://drbl.in/ikPx

My second project with some jQuery:
- Increase the "likes" when pressed.
- Switch Popular/Comments/Recent Tabs.

Forked from [Javier Latorre López-Villalta](http://codepen.io/jlalovi/)'s Pen [Tab Switch and Likes method (Dribble design)](http://codepen.io/jlalovi/pen/wJAgp/).