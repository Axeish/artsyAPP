$(document).ready(function() {

function changeTab(){
  var target = $(this).data('target');
  
  $('#tab-navigation li').removeClass('selected');
  $('#tab-navigation li').addClass('noSelected');
  $(this).removeClass('noSelected');
  $(this).addClass('selected');    
  $('.tabContainer').addClass('hidden');
  $(target).removeClass('hidden');
}

function increaseLikes(){
  var myString = $(this).children('.nLikes').first().html();
  var myInteger = parseInt(myString);
  var myNewInteger = myInteger + 1;
  var nlikesUp = myNewInteger.toString();

  $(this).children('.nLikes').first().html(nlikesUp);
}

$('#tab-navigation li').click(changeTab);
$('.likes').click(increaseLikes);

});